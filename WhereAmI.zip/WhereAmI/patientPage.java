package waiijo.alzheimertracking;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
/**
 * Created by mamay on 20/5/2560.
 */

public class patientPage extends Activity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.whereami);
    }
    public void linkMap(View view){
        startActivity(new Intent(this,MapsActivity.class));
    }
}
