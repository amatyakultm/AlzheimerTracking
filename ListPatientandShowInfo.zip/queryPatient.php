 <?php  
 require "dbconnect.php"; 
 // $ctID = $_POST["ctID"]; 
 $ctID = 4; 
 $sql_query = "select * from Patient where ctID like '$ctID';";

 $result = mysqli_query($conn,$sql_query); 
 $resultArray = array();

 if(mysqli_num_rows($result) >0 )  
 {  
 	$rows = array();
	while($r = mysqli_fetch_assoc($result)) {
	    $rows[] = $r;
	}
	$data = array("data"=>$rows);
	echo json_encode($data);
 }  
 else  
 {   
 echo "Failed to load Patient list.";  
 }  
 ?>  