package com.example.kiranaamat.listpatient;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class CustomAdapter extends BaseAdapter {

    private ViewHolder mViewHolder;

    private LayoutInflater mInflater;
    List<Patient> mPatients;

    public CustomAdapter(Activity activity, List<Patient> patients) {
        mInflater = (LayoutInflater) activity.getSystemService(
                Context.LAYOUT_INFLATER_SERVICE);
        mPatients = patients;
    }

    @Override
    public int getCount() {
        return mPatients.size();
    }

    @Override
    public Object getItem(int position) {
        return mPatients.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.row, parent, false);
            mViewHolder = new ViewHolder();
            mViewHolder.name = (TextView) convertView.findViewById(R.id.patient_name);
            mViewHolder.tel = (TextView) convertView.findViewById(R.id.patient_tel);
            convertView.setTag(mViewHolder);

            Patient patient = mPatients.get(position);

            mViewHolder.name.setText(patient.getFName()+" "+patient.getLName());
            mViewHolder.tel.setText(patient.getPhoneNum());

        } else {
            mViewHolder = (ViewHolder) convertView.getTag();
        }

        return convertView;
    }

    private static class ViewHolder{
        TextView name;
        TextView tel;
    }

}