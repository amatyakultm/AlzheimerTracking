package com.example.kiranaamat.listpatient;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import com.google.gson.Gson;

public class MainActivity extends AppCompatActivity {

    public static final String URL =
            "http://blog.teamtreehouse.com/api/get_recent_summary/";
    private ListView mListView;
    private CustomAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mListView = (ListView) findViewById(R.id.listView);
        new SimpleTask().execute(URL);
    }

    private void showData(String jsonString) {
        Gson gson = new Gson();
        Datas datas = gson.fromJson(jsonString, Datas.class);


        StringBuilder builder = new StringBuilder();
        builder.setLength(0);

        List<Patient> patients = datas.getData();

        mAdapter = new CustomAdapter(this, patients);
        mListView.setAdapter(mAdapter);

        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> a,
                                    View v, int position, long id) {
                Patient patient = (Patient) a.getItemAtPosition(position);
                Intent intent = new Intent(getApplicationContext(), DetailActivity.class);
                intent.putExtra("fName", patient.getFName());
                intent.putExtra("lName", patient.getLName());
                intent.putExtra("tel", patient.getPhoneNum());
                intent.putExtra("address", patient.getAddress());
                startActivity(intent);
            }
        });

//        Toast.makeText(this, jsonString, Toast.LENGTH_LONG).show();
    }

    private class SimpleTask extends AsyncTask<String, Void, String> {

        @Override
        protected void onPreExecute() {
            // Create Show ProgressBar
        }

        protected String doInBackground(String... urls)   {
            try {
                String resText = GetResponseText("http://waiijoswag.esy.es/queryPatient.php?");
                return resText;
            } catch (IOException e) {
                e.printStackTrace();
            }
            return "";
        }

        protected void onPostExecute(String jsonString)  {
            // Dismiss ProgressBar
            showData(jsonString);
        }

        private String GetResponseText(String stringUrl) throws IOException {
            StringBuilder response = new StringBuilder();
            java.net.URL url = new URL(stringUrl);
            HttpURLConnection httpconn = (HttpURLConnection) url.openConnection();
            if (httpconn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                BufferedReader input = new BufferedReader(new InputStreamReader(httpconn.getInputStream()), 8192);
                String strLine = null;
                while ((strLine = input.readLine()) != null) {
                    response.append(strLine);
                }
                input.close();
            } else {
                return null;
            }
            return response.toString();
        }
    }
}
