package com.example.kiranaamat.listpatient;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        TextView pat_fname = (TextView)findViewById(R.id.patient_fname);
        TextView pat_lname = (TextView)findViewById(R.id.patient_lname);
        TextView pat_tel = (TextView)findViewById(R.id.patient_tel);
        TextView pat_address = (TextView)findViewById(R.id.patient_address);

        Intent intent= getIntent();
        String fName = intent.getStringExtra("fName");
        String lName = intent.getStringExtra("lName");
        String tel = intent.getStringExtra("tel");
        String address = intent.getStringExtra("address");

        pat_fname.setText(fName);
        pat_lname.setText(lName);
        pat_tel.setText(tel);
        pat_address.setText(address);

    }
}
