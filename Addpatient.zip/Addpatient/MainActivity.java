package com.example.waiijo.waiijo;


import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.app.Activity;


public class MainActivity extends Activity {
    String fName;
    String lName;
    String phoneNum;
    String address;

    EditText txtfName,txtlName,txtphoneNum,txtaddress;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtfName = (EditText) findViewById(R.id.fName);
        txtlName = (EditText) findViewById(R.id.lName);
        txtphoneNum = (EditText) findViewById(R.id.phoneNum);
        txtaddress = (EditText) findViewById(R.id.address);
    }
    public void addPatient(View view){
        fName = txtfName.getText().toString();
        lName = txtlName.getText().toString();
        phoneNum = txtphoneNum.getText().toString();
        address = txtaddress.getText().toString();
        String method = "Add";
        Bg bg = new Bg(this);
        bg.execute(fName,lName,phoneNum,address);
        finish();
    }
}