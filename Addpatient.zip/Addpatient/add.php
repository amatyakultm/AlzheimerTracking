<?php
    include_once("dbconnect.php");
    
    if(isset($_POST['fName']) && isset($_POST['lName'])&& isset($_POST['tel'])&& isset($_POST['address']))
    {
        $fName = $_POST['fName'];
        $lName = $_POST['lName'];
        $address = $_POST['address'];
        $tel = $_POST['tel'];
        $strSQL = "INSERT INTO Patient(ctID,fName,lName,phoneNum,address)
        VALUES (
                '3',
                '$fName',
                '$lName',
                '$tel',
                '$address'
                )
        ";
        $objQuery = mysqli_query($conn,$strSQL);
        if(!$objQuery)
        {
            $arr['StatusID'] = "0";
            $arr['Error'] = "Cannot save data!";
        }
        else
        {
            $arr['StatusID'] = "1";
            $arr['Error'] = "";
        }
    }
    else
    {
        echo "isset error!";
    }
    echo json_encode($arr);
    ?>